# import util, math, random,collections
# from util import Belief, pdf 
# from engine.const import Const

# # Class: Estimator
# #----------------------
# # Maintain and update a belief distribution over the probability of a car being in a tile.
# class Estimator(object):
#     def __init__(self, numRows: int, numCols: int):
#         self.belief = util.Belief(numRows, numCols) 
#         self.transProb = util.loadTransProb() 
#         self.transProbDict = dict()
#         for (oldTile, newTile) in self.transProb:
#             if not oldTile in self.transProbDict:
#                 self.transProbDict[oldTile] = collections.Counter()
#             self.transProbDict[oldTile][newTile] = self.transProb[(oldTile, newTile)]

#         # Initialize the particles randomly
#         self.particles = collections.Counter()
#         potentialParticles = self.transProbDict.keys()
#         for i in range(self.NUM_PARTICLES):
#             particleIndex = int(random.random() * len(potentialParticles))
#             self.particles[potentialParticles[particleIndex]] += 1

#         self.updateBelief()
            
#     ##################################################################################
#     # [ Estimation Problem ]
#     # Function: estimate (update the belief about a StdCar based on its observedDist)
#     # ----------------------
#     # Takes |self.belief| -- an object of class Belief, defined in util.py --
#     # and updates it *inplace* based onthe distance observation and your current position.
#     #
#     # - posX: x location of AutoCar 
#     # - posY: y location of AutoCar 
#     # - observedDist: current observed distance of the StdCar 
#     # - isParked: indicates whether the StdCar is parked or moving. 
#     #             If True then the StdCar remains parked at its initial position forever.
#     # 
#     # Notes:
#     # - Carefully understand and make use of the utilities provided in util.py !
#     # - Remember that although we have a grid environment but \
#     #   the given AutoCar position (posX, posY) is absolute (pixel location in simulator window).
#     #   You might need to map these positions to the nearest grid cell. See util.py for relevant methods.
#     # - Use util.pdf to get the probability density corresponding to the observedDist.
#     # - Note that the probability density need not lie in [0, 1] but that's fine, 
#     #   you can use it as probability for this part without harm :)
#     # - Do normalize self.belief after updating !!

#     ###################################################################################
#     def estimate(self, agentX: float, agentY: float, observedDist: float, isParked: bool) -> None:
#         # BEGIN_YOUR_CODE
#         for  row in range(self.belief.getNumRows()):
#             for col in range(self.belief.getNumCols()):
#                 x = util.colToX(col)
#                 y = util.rowToY(row)
#                 prior = self.belief.getProb(row, col)
#                 likelihood = util.pdf(math.sqrt((agentX - x) ** 2 + (agentY - y) ** 2), Const.SONAR_STD, observedDist)
#                 posterior = prior * likelihood
#                 self.belief.setProb(row, col, posterior)
#         self.belief.normalize()
#         return
#         # END_YOUR_CODE

 
#     def elapseTime(self):
        
#         # BEGIN_YOUR_CODE (around 10 lines of code expected)
#         newBelief = util.Belief(self.belief.getNumRows(), self.belief.getNumCols(), 0)
#         for (oldTile, newTile) in self.transProb:
#             posterior = self.belief.getProb(oldTile[0], oldTile[1])
#             transition = self.transProb[(oldTile, newTile)]
#             delta = posterior * transition
#             newBelief.addProb(newTile[0], newTile[1], delta)
#         newBelief.normalize()
#         self.belief = newBelief
#         # END_YOUR_CODE


#     def __init__(self, numRows, numCols):
#         self.belief = util.Belief(numRows, numCols)

#         # Load the transition probabilities and store them in a dict of Counters
#         # self.transProbDict[oldTile][newTile] = probability of transitioning from oldTile to newTile
#         self.transProb = util.loadTransProb()

#     # Function: Update Belief
#     # ---------------------
#     # Updates |self.belief| with the probability that the car is in each tile
#     # based on |self.particles|, which is a Counter from particle to
#     # probability (which should sum to 1).
#     def updateBelief(self):
#         newBelief = util.Belief(self.belief.getNumRows(), self.belief.getNumCols(), 0)
#         for tile in self.particles:
#             newBelief.setProb(tile[0], tile[1], self.particles[tile])
#         newBelief.normalize()
#         self.belief = newBelief


#     def elapseTime(self):
#         # BEGIN_YOUR_CODE (around 10 lines of code expected)
#         newParticles = collections.Counter()
#         for tile in self.particles:
#             for i in range(self.particles[tile]):  # if on that tile there're more particles, that tile is
#                 # an important start point
#                 newTile = util.weightedRandomChoice(self.transProbDict[tile])
#                 # wherever newTile it lands, increase that counter.
#                 newParticles[newTile] += 1
#         self.particles = newParticles
#         # END_YOUR_CODE

#     # Function: Get Belief
#     # ---------------------
#     # Returns your belief of the probability that the car is in each tile. Your
#     # belief probabilities should sum to 1.
#     def getBelief(self):
#         return self.belief


import util , collections , random , math
from util import Belief, pdf 
from engine.const import Const

def weightedRandomChoice(weightDict):
    weights = []
    elems = []
    for elem in weightDict:
        weights.append(weightDict[elem])
        elems.append(elem)
    total = sum(weights)
    key = random.uniform(0, total)
    runningTotal = 0.0
    chosenIndex = None
    for i in range(len(weights)):
        weight = weights[i]
        runningTotal += weight
        if runningTotal > key:
            chosenIndex = i
            return elems[chosenIndex]
    raise Exception('Should not reach here')
# Class: Estimator
#----------------------
# Maintain and update a belief distribution over the probability of a car being in a tile.
class Estimator(object):
    NUM_PARTICLES=200
    def _init_(self, numRows: int, numCols: int):
        self.belief = util.Belief(numRows, numCols) 
        self.transProb = util.loadTransProb() 
       
        self.transProbDict = dict()
        for (oldTile, newTile) in self.transProb:
            if not oldTile in self.transProbDict:
                self.transProbDict[oldTile] = collections.Counter()
            self.transProbDict[oldTile][newTile] = self.transProb[(oldTile, newTile)]

        # Initialize the particles randomly
        self.particles = collections.Counter()
        potentialParticles = list(self.transProbDict.keys())
        for i in range(self.NUM_PARTICLES):
            particleIndex = int(random.random() * len(potentialParticles))
            self.particles[potentialParticles[particleIndex]] += 1

        self.updateBelief()

    # Function: Update Belief
    # ---------------------
    # Updates |self.belief| with the probability that the car is in each tile
    # based on |self.particles|, which is a Counter from particle to
    # probability (which should sum to 1).
    def updateBelief(self):
            newBelief = util.Belief(self.belief.getNumRows(), self.belief.getNumCols(), 0)
            for tile in self.particles:
                newBelief.setProb(tile[0], tile[1], self.particles[tile])
            newBelief.normalize()
            self.belief = newBelief
            
    ##################################################################################
    # [ Estimation Problem ]
    # Function: estimate (update the belief about a StdCar based on its observedDist)
    # ----------------------
    # Takes |self.belief| -- an object of class Belief, defined in util.py --
    # and updates it inplace based onthe distance observation and your current position.
    #
    # - posX: x location of AutoCar 
    # - posY: y location of AutoCar 
    # - observedDist: current observed distance of the StdCar 
    # - isParked: indicates whether the StdCar is parked or moving. 
    #             If True then the StdCar remains parked at its initial position forever.
    # 
    #
    # Notes:
    # - Carefully understand and make use of the utilities provided in util.py !
    # - Remember that although we have a grid environment but \
    #   the given AutoCar position (posX, posY) is absolute (pixel location in simulator window).
    #   You might need to map these positions to the nearest grid cell. See util.py for relevant methods.
    # - Use util.pdf to get the probability density corresponding to the observedDist.
    # - Note that the probability density need not lie in [0, 1] but that's fine, 
    #   you can use it as probability for this part without harm 🙂
    # - Do normalize self.belief after updating !!

    ###################################################################################
    def estimate(self, posX: float, posY: float, observedDist: float, isParked: bool) -> None:
        # BEGIN_YOUR_CODE
        for tile in self.particles.keys():
            x = util.colToX(tile[1])
            y = util.rowToY(tile[0])
            prior = self.particles[tile]
            likelihood = util.pdf(math.sqrt((posX - x) * 2 + (posY - y) * 2), Const.SONAR_STD, observedDist)
            posterior = prior * likelihood
            self.particles[tile] = posterior
        newParticles = collections.Counter()
        for i in range(self.NUM_PARTICLES):
            sample = weightedRandomChoice(self.particles)
            newParticles[sample] += 1
        self.particles = newParticles
        # END_YOUR_CODE
        self.updateBelief()
        newParticles = collections.Counter()
        for tile in self.particles:
            for i in range(self.particles[tile]):  # if on that tile there're more particles, that tile is
                # an important start point
                newTile = weightedRandomChoice(self.transProbDict[tile])
                # wherever newTile it lands, increase that counter.
                newParticles[newTile] += 1
        self.particles = newParticles

        # END_YOUR_CODE
        return
    
  
    def getBelief(self) -> Belief:
        return self.belief