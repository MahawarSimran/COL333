from queue import Queue
import json





dict={'a': ['e', 'i', 'o', 'q', 'u'], 'b': ['d', 'p', 'v'], 'c': ['g', 'k', 'q', 's', 't', 'x', 'z'], 'd': ['b', 'g', 'j', 'l', 'm', 'n', 's', 't'], 'e': ['a', 'd', 'h', 'i', 'o', 'r', 'u', 'w', 'y'], 'f': ['p', 'v'], 'g': ['c', 'd', 'f', 'j', 'k', 'q', 'z'], 'h': ['j', 'k', 't', 'w'], 'i': ['a', 'e', 'h', 'l', 'o', 'u', 'y'], 'j': ['g'], 'k': ['c'], 'l': ['f', 'r'], 'm': ['b', 'n', 'p'], 'n': ['h', 'm', 'r', 'v'], 'o': ['a', 'e', 'u', 'y'], 'p': ['b', 'm'], 'q': [], 'r': ['f', 'l', 'n', 'w'], 's': ['c', 't', 'x', 'z'], 't': ['c', 'd', 'g', 'h', 'k', 'l', 'm', 'n', 'p', 'q', 's', 'v', 'x'], 'u': ['a', 'e', 'i', 'o', 'r', 'w', 'y'], 'v': ['b', 'f', 'j'], 'w': [], 'x': ['z'], 'y': ['i'], 'z': ['s', 'x']}

class Node:
    def __init__(self,value,costfn):
        self.value=value
        self.size=len(value)
        self.cost=costfn(value)
        self.fun=costfn

    def __eq__(self, other):
        return (self.cost == other.cost)

    def __ne__(self, other):
        return not (self == other)

    def __lt__(self, other):
        return (self.cost < other.cost) and (self.cost < other.cost)

    def __gt__(self, other):
        return (self.cost > other.cost) and (self.cost > other.cost)

    def __le__(self, other):
        return (self < other) or (self == other)

    def __ge__(self, other):
        return (self > other) or (self == other)

    def childs(self):
        # Returns the list of all possible strings that can be formed by making one correction.
        child=[]
        for i in range(self.size):
            l=[]
            x=self.value[i]
            if(x!= ' '):
                changed=dict[x]
                for a in changed:
                    y=self.value[:i]+a+self.value[i+1:]
                    p=Node(y,self.fun)
                    l.append(p)
            child=child+l
        return child
    
   
    def sort(self,l):
        L=[]
        for node in l:
            x=(node.cost,node)
            L.append(x)
        L.sort()
        Rslt=[b for (a,b) in L]
        return Rslt

    def bestchoice(self,l):
        L=[]
        for node in l:
            if(node.cost<self.cost):
                L.append(node)
        return L

k=3


class SentenceCorrector(object):
    def __init__(self, cost_fn, conf_matrix):
        self.conf_matrix = conf_matrix
        self.cost_fn = cost_fn
        self.best_state = None  

    def search(self, start_state):
        global dict
        global k
        with open('./data/conf_matrix.json') as json_file:
            data = json.load(json_file)
            d = {}
            for val in range(97,123):
                d[chr(val)] = []
            for val in range(97,123):
                for xx in range(0,4):
                    asd = data[chr(val)][xx]
                    d[asd].append(chr(val))
        dict=d
        root=Node(start_state,self.cost_fn)
        bestNode=root
        self.best_state=bestNode.value
        print()
        print("=============================================")
        print("Start State: ",start_state)
        print("=============================================")
        print()

        frontier=Queue()
        frontier.put(root)
        explored=[]
        count=0
        while(True):
            count+=1
            if(frontier.empty()):
                return []
            nextfrontier=[]
            while(not frontier.empty()):
                node=frontier.get()
                explored.append(node)
                succesors=node.childs()
                sorted_array=node.sort(succesors)
                for next in sorted_array:
                    if(next not in explored) and (next not in nextfrontier):
                        nextfrontier.append(next)
           
            next=[]
            sortedNext=root.sort(nextfrontier)
            if(len(sortedNext)!=0):
                if (sortedNext[0].cost<bestNode.cost):
                    self.best_state=sortedNext[0].value
                    bestNode=sortedNext[0]
                    print("Best state:",self.best_state)
                if(k<=len(sortedNext)):
                    for i in range(k):
                        frontier.put(sortedNext[i])
                else:
                    for i in range(len(sortedNext)):
                        frontier.put(sortedNext[i])
                
        """
        :param start_state: str Input string with spelling errors
        """
        
        # You should keep updating self.best_state with best string so far.
        # self.best_state = start_state
        raise Exception("Not Implemented.")
