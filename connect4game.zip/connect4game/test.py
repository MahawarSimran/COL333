from typing import List, Tuple, Dict, Union

import numpy as np

from connect4.config import debug_mode, win_pts


class Integer:
    """
    Used to manage num pop counts in state. Normal python integer cannot be passed by reference.
    Thus, we created this integer class
    """

    def __init__(self, i: int):
        self._i = i
        self._initial = i

    def decrement(self) -> None:
        assert not debug_mode or self._i > 0
        self._i -= 1

    def increment(self) -> None:
        assert not debug_mode or self._i <= self._initial
        self._i += 1

    def get_int(self) -> int:
        return self._i


class Node:
    def __init__(self,state,player_number):
        self.player=player_number
        self.state=state
    def make_move(self,column, is_popout):
        
        board, temp = self.state
        m = board.shape[0]
        n = board.shape[1]
        print(m)
        aa = np.zeros((m,n))
        i =0
        while(i < m):
            for j in range(n):
                aa[i][j] = board[i][j]
            i +=1
        i =0
        if(is_popout):
            while(i<m-1):
                aa[i+1][column] = board[i][column]
                i+=1
            aa[0][column] =0
        else:
            i =m-1
            while(i>=0):
                if(aa[i][column] == 0):
                    print(aa[i][column])
                    aa[i][column] = self.player
                    print(self.player)
                    break
                i -= 1
        return aa
        
    def make_child(self,column,ispopOut):
        board , popout = self.state
        leftpopout=dict()
        leftpopout[self.player]= Integer(popout[self.player]._i-1)
        nextplayer=1
        if(self.player==1):
            nextplayer=2
            leftpopout[2]=Integer(popout[2]._i)
        else:
            leftpopout[1]=Integer(popout[1]._i)
        u=Node((self.make_move(column,ispopOut),leftpopout),nextplayer)
        return u


popout={}
popout[1]=Integer(1)
popout[2]=Integer(2)

board = np.array([[1, 3,  0, 4], [4,3,4,1], [1,8,9,4], [5,5,5,5]])
state=board,popout

u= Node(state,1)
board1=u.make_move(2 ,True) 

print(board)
print(board1)